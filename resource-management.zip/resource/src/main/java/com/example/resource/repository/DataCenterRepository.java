package com.example.resource.repository;

import com.example.resource.model.DataCenter;
import com.example.resource.model.request.DataCenterRequest;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DataCenterRepository {
    Optional<DataCenter> save(DataCenter dataCenter);
    Optional<DataCenter> findById(int id);
    Optional<List<DataCenter>> findByLocation(String location);
}
