package com.example.resource.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Builder
@Getter
@Setter
public class DataCenter {
    private int id;
    private String location; // ToDo:: Location Object/Pojo can be used but it is out of scope
}
