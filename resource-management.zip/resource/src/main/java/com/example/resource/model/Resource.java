package com.example.resource.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Builder
@Getter
@Setter
public class Resource {
    private int id;
    // UUID should be used for Prod. To test and keep things simple, use integer as an Id here.
    private int dataCenterId;
    private int cpu;
    private boolean available;
    private int cost; // Assumed Cost per minute as we get start and end time for each task
}
