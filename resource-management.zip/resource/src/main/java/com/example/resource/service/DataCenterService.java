package com.example.resource.service;

import com.example.resource.model.DataCenter;
import com.example.resource.model.request.DataCenterRequest;
import com.example.resource.repository.DataCenterRepository;
import com.example.resource.service.dto.DataCenterDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DataCenterService {

    @Autowired
    private DataCenterRepository dataCenterRepository;

    @Autowired
    private DataCenterDTO dataCenterDTO;

    public ResponseEntity<DataCenter> save(DataCenterRequest request) {
        DataCenter dataCenter = dataCenterDTO.getDataCenter(request);
        Optional<DataCenter> savedDataCenter = dataCenterRepository.save(dataCenter);
        return savedDataCenter.map(dataCenterObj ->
                new ResponseEntity<>(dataCenterObj, HttpStatusCode.valueOf(HttpStatus.CREATED.value())))
                .orElse(new ResponseEntity<>(HttpStatusCode.valueOf(HttpStatus.BAD_REQUEST.value())));
    }

    public ResponseEntity<DataCenter> findById(int dataCenterId) {
        Optional<DataCenter> dataCenter = dataCenterRepository.findById(dataCenterId);
        return dataCenter.map(dataCenterObj ->
                        new ResponseEntity<>(dataCenterObj, HttpStatusCode.valueOf(HttpStatus.OK.value())))
                .orElse(new ResponseEntity<>(HttpStatusCode.valueOf(HttpStatus.BAD_REQUEST.value())));
    }
}
