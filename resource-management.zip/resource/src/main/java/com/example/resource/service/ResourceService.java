package com.example.resource.service;

import com.example.resource.model.Resource;
import com.example.resource.model.request.ResourceCreationRequest;
import com.example.resource.model.request.ResourceTaskRequest;
import com.example.resource.repository.ResourceRepository;
import com.example.resource.service.dto.ResourceDTO;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class ResourceService {

    @Autowired
    private ResourceRepository resourceRepository;

    @Autowired
    private ResourceDTO resourceDTO;

    public ResponseEntity<Resource> save(ResourceCreationRequest request) {
        Resource resource = resourceDTO.getResource(request);
        Optional<Resource> savedResource = resourceRepository.save(resource);
        return savedResource.map(resourceObj ->
                        new ResponseEntity<>(resourceObj, HttpStatusCode.valueOf(HttpStatus.CREATED.value())))
                .orElse(new ResponseEntity<>(HttpStatusCode.valueOf(HttpStatus.BAD_REQUEST.value())));
    }

    public ResponseEntity<Resource> findById(int resourceId) {
        Optional<Resource> resource = resourceRepository.findById(resourceId);
        return resource.map(resourceObj ->
                        new ResponseEntity<>(resourceObj, HttpStatusCode.valueOf(HttpStatus.OK.value())))
                .orElse(new ResponseEntity<>(HttpStatusCode.valueOf(HttpStatus.BAD_REQUEST.value())));
    }

    public ResponseEntity<List<Resource>> findAllByDataCenterId(int dataCenterId) {
        Optional<List<Resource>> resources = resourceRepository.findAllByDataCenter(dataCenterId);
        return resources.map(resourceList ->
                        new ResponseEntity<>(resourceList, HttpStatusCode.valueOf(HttpStatus.OK.value())))
                .orElse(new ResponseEntity<>(HttpStatusCode.valueOf(HttpStatus.BAD_REQUEST.value())));
    }

    public Optional<Resource> getAllocatedResourceForTask(ResourceTaskRequest request) {
        Optional<Resource> resourceListOptional = findResourceByCpu(request.getCpu());

        if (resourceListOptional.isEmpty()) {
            Optional<Integer> nextCpu = findNextCpuSize(request.getCpu());

            /** When we ran out of CPU power, logging an error and return null */
            if (nextCpu.isEmpty()) {
                log.error("No Resources found for this CPU : {}", request.getCpu());
                return null;
            }
            request.setCpu(nextCpu.get().intValue());
            return getAllocatedResourceForTask(request);
        }

        return resourceListOptional;
    }

    public Optional<Resource> findResourceByCpu(int cpu) {
        // find by cpu size, if available allocate --> diff algorithms can be used like by location
        Optional<List<Resource>> resourceListOptional = resourceRepository.findAllByCpuSize(cpu);
        Optional<Resource> resourceByCpu = resourceListOptional.flatMap(resources -> {
            return resources.stream()
                    .sorted(Comparator.comparing(Resource::getCost)) // sort prices low to high
                    .filter(Resource::isAvailable) // Algorithm for near by location can be done
                    .findFirst();
        });

        if (resourceByCpu.isPresent()) {
            log.info("Resource with id:{} found for request with cpu: {}",
                    resourceByCpu.get().getId(), cpu);
            allocateResource(resourceByCpu.get());
            return resourceByCpu;
        }
        return Optional.empty();
    }

    private void allocateResource(Resource resource) {
        resource.setAvailable(false); // allocated
    }

    private void freeResource(Resource resource) {
        resource.setAvailable(true);
    }

    private Optional<Integer> findNextCpuSize(int cpu) {
        // ToDo when current cpu size is not present, look for next size.
        return Optional.empty();
    }
}
