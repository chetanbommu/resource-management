package com.example.resource.repository;

import com.example.resource.model.Resource;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ResourceRepository {
    Optional<Resource> save(Resource resource);
    Optional<Resource> findById(int id);
    Optional<List<Resource>> findAllByDataCenter(int dataCenterId);

    Optional<List<Resource>> findAllByCpuSize(int cpu);
}
