package com.example.resource.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResourceTaskRequest {
    private int cpu;
    private int organisationId; // Org or Company who requested resource, this can be used for billing.
    private long startTime; // Frontend to send us epoch time or time in ms (this can be handled)
    private long endTime;
}
