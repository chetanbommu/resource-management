package com.example.resource.controller;

import com.example.resource.model.DataCenter;
import com.example.resource.model.request.DataCenterRequest;
import com.example.resource.service.DataCenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController("/data-centers")
public class DataCenterController {

    @Autowired
    private DataCenterService dataCenterService;

    @PostMapping
    public ResponseEntity<DataCenter> createDataCenter(@RequestBody DataCenterRequest request) {
        return dataCenterService.save(request);
    }

    @GetMapping("/{dataCenterId}")
    public ResponseEntity<DataCenter> getDataCenterById(@PathVariable(name = "dataCenterId") int dataCenterId) {
        return dataCenterService.findById(dataCenterId);
    }
}
