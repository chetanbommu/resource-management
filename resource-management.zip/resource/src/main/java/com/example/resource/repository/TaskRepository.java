package com.example.resource.repository;

import com.example.resource.model.Task;

import java.util.List;
import java.util.Optional;

public interface TaskRepository {
    Optional<Task> save(Task task);
    Optional<Task> findById(int id);
    Optional<List<Task>> findByResourceId(int resourceId);
    Optional<List<Task>> findAllByOrganisation(int companyId);
}
