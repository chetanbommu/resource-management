package com.example.resource.repository;

import com.example.resource.model.Task;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class TaskRepositoryImpl implements TaskRepository {

    private int TASK_ID = 1; // ToDo : Use IdGenerator Service to implement

    private Map<Integer, Task> taskMap = new HashMap<>();

    private Map<Integer, List<Task>> organisationToTaskMap = new HashMap<>();
    private Map<Integer, List<Task>> resourceToTaskMap = new HashMap<>();

    private int getNewId() {
        int id = TASK_ID;
        incrementId();
        return id;
    }

    private void incrementId() {
        TASK_ID++;
    }

    @Override
    public Optional<Task> save(Task task) {
        int taskId = getNewId();
        task.setId(taskId);

        // Add the new task entity to In-Memory Database
        taskMap.put(taskId, task);

        List<Task> taskListForOrganisation =
                organisationToTaskMap.getOrDefault(task.getOrganisationId(), new ArrayList<>());
        taskListForOrganisation.add(task);
        organisationToTaskMap.put(task.getOrganisationId(), taskListForOrganisation);

        List<Task> taskListForResource =
                organisationToTaskMap.getOrDefault(task.getResourceId(), new ArrayList<>());
        taskListForResource.add(task);
        resourceToTaskMap.put(task.getResourceId(), taskListForResource);

        return Optional.of(task);
    }

    @Override
    public Optional<Task> findById(int id) {
        return taskMap.containsKey(id)
                ? Optional.of(taskMap.get(id)) : Optional.empty();
    }

    @Override
    public Optional<List<Task>> findByResourceId(int resourceId) {
        return resourceToTaskMap.containsKey(resourceId)
                ? Optional.of(resourceToTaskMap.get(resourceId)) : Optional.empty();
    }

    @Override
    public Optional<List<Task>> findAllByOrganisation(int organisationId) {
        return organisationToTaskMap.containsKey(organisationId)
                ? Optional.of(organisationToTaskMap.get(organisationId)) : Optional.empty();
    }
}
