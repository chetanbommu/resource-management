package com.example.resource.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Builder
@Getter
@Setter
public class Task {
    private int id;
    private int organisationId;
    private int resourceId;
    private long startTime;
    private long endTime;

}
