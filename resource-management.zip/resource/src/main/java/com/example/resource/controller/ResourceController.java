package com.example.resource.controller;

import com.example.resource.model.Resource;
import com.example.resource.model.request.ResourceCreationRequest;
import com.example.resource.service.ResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController("/resources")
public class ResourceController {

    @Autowired
    private ResourceService resourceService;

    @PostMapping
    public ResponseEntity<Resource> createResource(@RequestBody ResourceCreationRequest request) {
        return resourceService.save(request);
    }

    @GetMapping("/{resourceId}")
    public ResponseEntity<Resource> getResourceById(@PathVariable(name = "resourceId") int resourceId) {
        return resourceService.findById(resourceId);
    }

    @GetMapping("/data-center/{dataCenterId}")
    public ResponseEntity<List<Resource>> getResourceByDataCenter(@PathVariable(name = "dataCenterId") int dataCenterId) {
        return resourceService.findAllByDataCenterId(dataCenterId);
    }
}
