package com.example.resource.repository;

import com.example.resource.model.Resource;
import com.example.resource.model.request.ResourceCreationRequest;
import com.example.resource.service.dto.ResourceDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ResourceRepositoryImpl implements ResourceRepository {

    private int RESOURCE_ID = 1; // ToDo : Use IdGenerator Service to implement
    public Map<Integer, Resource> resourceMap = new HashMap<>();
    public Map<Integer, List<Resource>> dataCenterToResourceMap =
            new HashMap<>(); // Acts as indexing

    /** Acts as indexing, also used TreeMap as cpu sizes will be in sorted order
     * and helps in finding next best cpu for a given cpu */
    public Map<Integer, List<Resource>> cpuToResourceMap = new TreeMap<>();


    private int getNewId() {
        int id = RESOURCE_ID;
        incrementId();
        return id;
    }

    private void incrementId() {
        RESOURCE_ID++;
    }

    @Override
    public Optional<Resource> save(Resource resource) {
        int resourceId = getNewId();
        resource.setId(resourceId);

        // Add the new resource entity to In-Memory Database
        resourceMap.put(resourceId, resource);

        List<Resource> resourceListForDataCenter =
                dataCenterToResourceMap.getOrDefault(resource.getDataCenterId(), new ArrayList<>());
        resourceListForDataCenter.add(resource);
        dataCenterToResourceMap.put(resource.getDataCenterId(), resourceListForDataCenter);

        List<Resource> resourceListForCpuSize =
                cpuToResourceMap.getOrDefault(resource.getCpu(), new ArrayList<>());
        resourceListForCpuSize.add(resource);
        cpuToResourceMap.put(resource.getCpu(), resourceListForCpuSize);


        return Optional.of(resource);
    }

    @Override
    public Optional<Resource> findById(int resourceId) {
        return resourceMap.containsKey(resourceId)
                ? Optional.of(resourceMap.get(resourceId)) : Optional.empty();
    }

    @Override
    public Optional<List<Resource>> findAllByDataCenter(int dataCenterId) {
        return dataCenterToResourceMap.containsKey(dataCenterId)
                ? Optional.of(dataCenterToResourceMap.get(dataCenterId)) : Optional.empty();
    }

    @Override
    public Optional<List<Resource>> findAllByCpuSize(int cpu) {
        return cpuToResourceMap.containsKey(cpu)
                ? Optional.of(cpuToResourceMap.get(cpu)) : Optional.empty();
    }
}
