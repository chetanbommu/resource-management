package com.example.resource.repository;

import com.example.resource.model.DataCenter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.List;

@Component
public class DataCenterRepositoryImpl implements DataCenterRepository {

    // ToDo : Use IdGenerator Service to implement and adopt various strategies -- Out of Context for now
    private int DATA_CENTER_ID = 1;

    public Map<Integer, DataCenter> dataCenterMap = new HashMap<>();
    public Map<String, List<DataCenter>> locationToDataCenterMap =
            new HashMap<>(); // Acts as indexing

    @Override
    public Optional<DataCenter> save(DataCenter dataCenter) {
        int dataCenterId = getNewId();
        dataCenter.setId(dataCenterId);
        dataCenterMap.put(dataCenterId, dataCenter);

        List<DataCenter> dataCentersForLocation =
                locationToDataCenterMap.getOrDefault(dataCenter.getLocation(), new ArrayList<>());
        dataCentersForLocation.add(dataCenter);
        locationToDataCenterMap.put(dataCenter.getLocation(), dataCentersForLocation);
        return Optional.of(dataCenter);
    }

    @Override
    public Optional<DataCenter> findById(int id) {
        return dataCenterMap.containsKey(id)
                ? Optional.of(dataCenterMap.get(id)) : Optional.empty();
    }

    @Override
    public Optional<List<DataCenter>> findByLocation(String location) {
        return locationToDataCenterMap.containsKey(location)
                ? Optional.of(locationToDataCenterMap.get(location)) : Optional.empty();
    }

    private int getNewId() {
        int id = DATA_CENTER_ID;
        incrementId();
        return id;
    }
    private void incrementId() {
        DATA_CENTER_ID++;
    }
}
