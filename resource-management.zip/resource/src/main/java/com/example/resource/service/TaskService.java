package com.example.resource.service;

import com.example.resource.model.Resource;
import com.example.resource.model.Task;
import com.example.resource.model.request.ResourceTaskRequest;
import com.example.resource.repository.TaskRepository;
import com.example.resource.service.dto.TaskDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private TaskDTO taskDTO;

    @Autowired
    private ResourceService resourceService;

    public ResponseEntity<Task> createTaskAndAllocateResource(ResourceTaskRequest request) {
        // 1. Create Task
        Task task = taskDTO.getTask(request);

        // 2. Find Allocated Resource
        Optional<Resource> resource = resourceService.getAllocatedResourceForTask(request);
        if (resource.isEmpty()) {
            return new ResponseEntity<>(HttpStatusCode.valueOf(HttpStatus.NOT_IMPLEMENTED.value()));
        }
        task.setResourceId(resource.get().getId());
        Optional<Task> savedTask = taskRepository.save(task);
        return savedTask.map(taskObj ->
                        new ResponseEntity<>(taskObj, HttpStatusCode.valueOf(HttpStatus.CREATED.value())))
                .orElse(new ResponseEntity<>(HttpStatusCode.valueOf(HttpStatus.BAD_REQUEST.value())));
    }
}
