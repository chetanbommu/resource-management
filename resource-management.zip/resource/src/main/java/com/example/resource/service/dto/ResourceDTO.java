package com.example.resource.service.dto;

import com.example.resource.model.Resource;
import com.example.resource.model.request.ResourceCreationRequest;
import org.springframework.stereotype.Component;

@Component
public class ResourceDTO {

    public Resource getResource(ResourceCreationRequest request) {
        return Resource.builder()
                .dataCenterId(request.getDataCenterId())
                .cpu(request.getCpu())
                .cost(request.getCost())
                .available(true)
                .build();
    }
}
