package com.example.resource.service.dto;

import com.example.resource.model.DataCenter;
import com.example.resource.model.request.DataCenterRequest;
import org.springframework.stereotype.Component;

@Component
public class DataCenterDTO {

    public DataCenter getDataCenter(DataCenterRequest request) {
        return DataCenter.builder()
                .location(request.getLocation())
                .build();
    }
}
