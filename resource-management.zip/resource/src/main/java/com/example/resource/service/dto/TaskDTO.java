package com.example.resource.service.dto;

import com.example.resource.model.Task;
import com.example.resource.model.request.ResourceTaskRequest;
import org.springframework.stereotype.Component;

@Component
public class TaskDTO {

    public Task getTask(ResourceTaskRequest request) {
        return Task.builder()
                .organisationId(request.getOrganisationId())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .build();
    }
}
